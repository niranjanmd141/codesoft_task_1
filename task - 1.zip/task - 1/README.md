##First Step - 1 open command prompt  ##
##Second Step - 2 navigate to the directory where the file is located  ##
##Third Step - 3 type the command 'cd C:\Users\YourName\Downloads\signup-login-api'  ##
##Fourth Step - 4 type the command 'npm install'  ##
##Fifth Step - 5 type the command 'npm start'  ##
##Sixth Step - 6 open a web browser and navigate to 'http://localhost:3000' ##
##Seventh Step - 7 open directory file and select 'index.html' right click on that file then click on open with any browser ##
##Eighth Step -  you will see the signup and login page  ##